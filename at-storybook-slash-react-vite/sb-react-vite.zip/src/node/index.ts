import type { StorybookConfig } from '../types';

export function defineMain(config: StorybookConfig) {
  return config;
}
